"""
train.py — Training / evaluation loop with the paper's exact config (Sec 4.1).

Paper hyper-parameters (verbatim):
  optimizer = Adam, lr = 1e-3, weight_decay = 1e-8,
  batch_size = 20, input = 380x380, epochs = 20,
  metrics = Accuracy (Acc) and AUC, reported at image level,
  hardware = 2x RTX 4090 (use DataParallel / DDP for multi-GPU).

Usage:
  python -m sfcl.train --train_dir DATA/train --val_dir DATA/val \
      --backbone timm --epochs 20 --batch_size 20
"""
import argparse
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from sfcl.model import build_model
from sfcl.data import FaceCropDataset


def evaluate(model, loader, device):
    model.eval()
    ys, ps, correct, n = [], [], 0, 0
    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            logit = model(x)
            prob = torch.softmax(logit, 1)[:, 1]
            pred = logit.argmax(1)
            correct += (pred == y).sum().item(); n += y.numel()
            ys.append(y.cpu()); ps.append(prob.cpu())
    y = torch.cat(ys).numpy(); p = torch.cat(ps).numpy()
    acc = correct / max(n, 1)
    try:
        from sklearn.metrics import roc_auc_score
        auc = roc_auc_score(y, p) if len(set(y.tolist())) > 1 else float("nan")
    except Exception:
        auc = float("nan")
    return acc, auc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train_dir", required=True)
    ap.add_argument("--val_dir", required=True)
    ap.add_argument("--backbone", default="auto",
                    choices=["auto", "timm", "torchvision", "stub"])
    ap.add_argument("--epochs", type=int, default=20)       # paper: 20
    ap.add_argument("--batch_size", type=int, default=20)   # paper: 20
    ap.add_argument("--lr", type=float, default=1e-3)       # paper: 1e-3
    ap.add_argument("--weight_decay", type=float, default=1e-8)  # paper: 1e-8
    ap.add_argument("--size", type=int, default=380)        # paper: 380
    ap.add_argument("--workers", type=int, default=4)
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_model(backbone=args.backbone, pretrained=True).to(device)
    if torch.cuda.device_count() > 1:
        model = nn.DataParallel(model)   # paper used 2 GPUs

    tr = DataLoader(FaceCropDataset(args.train_dir, args.size),
                    batch_size=args.batch_size, shuffle=True,
                    num_workers=args.workers, drop_last=True)
    va = DataLoader(FaceCropDataset(args.val_dir, args.size),
                    batch_size=args.batch_size, shuffle=False,
                    num_workers=args.workers)

    opt = torch.optim.Adam(model.parameters(), lr=args.lr,
                           weight_decay=args.weight_decay)
    crit = nn.CrossEntropyLoss()

    for epoch in range(1, args.epochs + 1):
        model.train(); running = 0.0
        for x, y in tr:
            x, y = x.to(device), y.to(device)
            opt.zero_grad()
            loss = crit(model(x), y)
            loss.backward(); opt.step()
            running += loss.item() * y.size(0)
        acc, auc = evaluate(model, va, device)
        print(f"epoch {epoch:02d} | train_loss {running/len(tr.dataset):.4f} "
              f"| val_acc {acc:.4f} | val_auc {auc:.4f}")
        torch.save({"model": getattr(model, 'module', model).state_dict(),
                    "epoch": epoch}, f"sfcl_hcmf_epoch{epoch:02d}.pth")


if __name__ == "__main__":
    main()
