"""
spatial.py — Spatial-domain pipeline (Paper Sec. 3.1: EfficientNet-B4 backbone).

Returns BOTH:
  • a shallow feature map  X_S  (for the FAAE shallow-fusion module), and
  • a deep pooled vector   S    (1792-d for EfficientNet-B4) for HCMA.

The real paper uses EfficientNet-B4 pretrained on ImageNet. We load it from
`timm` if available, else `torchvision`, else fall back to a small runnable CNN
stub (so the repo imports and shape-tests anywhere). For real experiments,
install timm:  pip install timm   and set backbone="timm".
"""
import torch
import torch.nn as nn


class _Stub(nn.Module):
    """Tiny stand-in producing the right (shallow_map, S[1792]) shapes."""
    def __init__(self, shallow_ch=256, deep_dim=1792):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(3, 64, 3, 2, 1), nn.BatchNorm2d(64), nn.ReLU(True),
            nn.Conv2d(64, shallow_ch, 3, 2, 1), nn.BatchNorm2d(shallow_ch), nn.ReLU(True),
        )
        self.deep = nn.Sequential(
            nn.Conv2d(shallow_ch, 512, 3, 2, 1), nn.BatchNorm2d(512), nn.ReLU(True),
            nn.Conv2d(512, deep_dim, 3, 2, 1), nn.BatchNorm2d(deep_dim), nn.ReLU(True),
        )
        self.gap = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        x = x / 255.0
        shallow = self.stem(x)           # [B,256,H/4,W/4]
        d = self.deep(shallow)
        S = self.gap(d).flatten(1)       # [B,1792]
        return shallow, S


class SpatialBackbone(nn.Module):
    """EfficientNet-B4 wrapper. backbone ∈ {'auto','timm','torchvision','stub'}."""

    SHALLOW_CH = 256          # exposed for FAAE wiring
    DEEP_DIM = 1792           # EfficientNet-B4 final feature dim

    def __init__(self, backbone: str = "auto", pretrained: bool = True):
        super().__init__()
        self.kind = None
        if backbone in ("auto", "timm"):
            try:
                import timm
                self.net = timm.create_model(
                    "efficientnet_b4", pretrained=pretrained,
                    features_only=True, out_indices=(1, 4))
                self.kind = "timm"
                self.SHALLOW_CH = self.net.feature_info.channels()[0]
                self.DEEP_DIM = self.net.feature_info.channels()[1]
                self.gap = nn.AdaptiveAvgPool2d(1)
            except Exception:
                if backbone == "timm":
                    raise
        if self.kind is None and backbone in ("auto", "torchvision"):
            try:
                from torchvision.models import efficientnet_b4
                m = efficientnet_b4(weights="DEFAULT" if pretrained else None)
                self.features = m.features
                self.shallow_idx = 2     # early block for shallow map
                self.kind = "torchvision"
                self.gap = nn.AdaptiveAvgPool2d(1)
                self.DEEP_DIM = 1792
            except Exception:
                if backbone == "torchvision":
                    raise
        if self.kind is None:
            self.net = _Stub(self.SHALLOW_CH, self.DEEP_DIM)
            self.kind = "stub"

    def forward(self, x):
        if self.kind == "timm":
            shallow, deep = self.net(x / 255.0)
            return shallow, self.gap(deep).flatten(1)
        if self.kind == "torchvision":
            h = x / 255.0
            shallow = None
            for i, blk in enumerate(self.features):
                h = blk(h)
                if i == self.shallow_idx:
                    shallow = h
            return shallow, self.gap(h).flatten(1)
        return self.net(x)   # stub


if __name__ == "__main__":
    bb = SpatialBackbone(backbone="auto", pretrained=False)
    print("backbone kind:", bb.kind, "| shallow_ch:", bb.SHALLOW_CH,
          "| deep_dim:", bb.DEEP_DIM)
    x = torch.rand(2, 3, 376, 376) * 255
    sh, S = bb(x)
    print("shallow", tuple(sh.shape), "| S", tuple(S.shape))
