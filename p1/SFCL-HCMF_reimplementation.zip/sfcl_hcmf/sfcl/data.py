"""
data.py — Dataset & preprocessing (Paper Sec. 4.1).

Paper preprocessing:
  • extract frames from each video clip,
  • detect/crop the face with a face tracker (the paper uses dlib),
  • feed 380x380 face crops; block-wise DCT is computed inside the model.

This module gives a simple image-folder Dataset for already-extracted face
crops, organized as:

    root/
      real/  xxx.png ...
      fake/  yyy.png ...

For video datasets (FF++, Celeb-DF, DFDC) run your own frame extraction +
face cropping first (dlib / RetinaFace / MTCNN), then point this Dataset at the
crop folders. Face cropping code is intentionally left out (needs dlib and the
raw videos), but the expected interface is documented here.
"""
import os
from PIL import Image
import torch
from torch.utils.data import Dataset


class FaceCropDataset(Dataset):
    """Folder of real/ and fake/ face crops -> (tensor[0..255], label)."""

    def __init__(self, root: str, size: int = 380):
        self.size = size
        self.samples = []
        for label, name in [(0, "real"), (1, "fake")]:
            d = os.path.join(root, name)
            if not os.path.isdir(d):
                continue
            for f in os.listdir(d):
                if f.lower().endswith((".png", ".jpg", ".jpeg", ".bmp")):
                    self.samples.append((os.path.join(d, f), label))
        if not self.samples:
            raise RuntimeError(f"No images found under {root}/real|fake")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, i):
        path, label = self.samples[i]
        img = Image.open(path).convert("RGB").resize((self.size, self.size))
        # to [3,H,W] in 0..255 (model does YCbCr + DCT internally)
        x = torch.from_numpy(
            torch.ByteTensor(torch.ByteStorage.from_buffer(img.tobytes())).numpy()
            if False else _to_array(img)).float()
        x = x.view(self.size, self.size, 3).permute(2, 0, 1).contiguous()
        return x, label


def _to_array(img):
    import numpy as np
    return np.asarray(img, dtype="uint8").copy()


if __name__ == "__main__":
    print("FaceCropDataset expects root/real/*.png and root/fake/*.png")
