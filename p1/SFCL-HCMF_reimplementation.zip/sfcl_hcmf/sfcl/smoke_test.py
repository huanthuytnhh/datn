"""
smoke_test.py — verify every module's shapes end-to-end at paper resolution.
Run:  python -m sfcl.smoke_test
"""
import torch
from sfcl.dct import BlockDCT
from sfcl.sida import SIDA
from sfcl.local_branch import LocalBranch
from sfcl.fusion import FAAE, HCMA
from sfcl.spatial import SpatialBackbone
from sfcl.model import build_model


def main():
    B, S = 2, 380   # paper input size (auto-padded to 384 for DCT)
    x = torch.rand(B, 3, S, S) * 255

    xt = BlockDCT()(x)
    print(f"[DCT]   in {tuple(x.shape)} -> X~ {tuple(xt.shape)}")

    D = SIDA()(xt)
    assert D.shape == (B, 2304), D.shape
    print(f"[SIDA]  X~ -> D {tuple(D.shape)}  (=2304 ✓)")

    Fv, sb = LocalBranch()(xt)
    assert Fv.shape == (B, 2048), Fv.shape
    print(f"[LOCAL] X~ -> F {tuple(Fv.shape)} (=2048 ✓), SBCM map {tuple(sb.shape)}")

    bb = SpatialBackbone(backbone="stub", pretrained=False)
    shallow, Svec = bb(x)
    print(f"[SPAT]  shallow {tuple(shallow.shape)}, S {tuple(Svec.shape)}")

    ys = FAAE(spatial_ch=bb.SHALLOW_CH)(shallow, sb)
    assert ys.shape == shallow.shape
    print(f"[FAAE]  Y_S {tuple(ys.shape)}  (== X_S ✓)")

    ff = HCMA(s_dim=bb.DEEP_DIM)(Svec, Fv, D)
    print(f"[HCMA]  F_fused {tuple(ff.shape)}")

    model = build_model(backbone="stub", pretrained=False)
    out = model(x)
    assert out.shape == (B, 2), out.shape
    out.sum().backward()
    n = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"[FULL]  logits {tuple(out.shape)} (=2 ✓), params {n:.1f}M, backward ✓")
    print("\nALL SHAPE CHECKS PASSED.")


if __name__ == "__main__":
    main()
